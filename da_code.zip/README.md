# Executing the pipeline

Before executing ensure you are either running in a virtual environment, using venv. Then install the requirements.txt

To get a description of the arguments and commands you can use.
```python main.py --help```

To run multiple files
```python main.py PATH_TO_FILE1 PATH_TO_FILE2 ... PATH_TO_FILE_N

To run with multiple directories of data
```python main.py --data-dir PATH_TO_DIRECTORY```